class AppRoute {
  static String splash = "/splash";
  static String productDetail = "/productDetail";
  static String productList = "/productList";
  static String updateProduct = "/updateProduct";
  static String cart = "/cart";
}
