class ApiConstants {
  static const String baseUrl = "https://dummyjson.com";

  static const String products = "$baseUrl/products";
}
